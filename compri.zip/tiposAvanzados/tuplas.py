#para definir tuplas utilizamos parentesis redondo
#la tuplas se usan cuando no queremos modificar los elementos
numeros = (1,2,3,4,5,7)
