def pagado():
    print("pagado")