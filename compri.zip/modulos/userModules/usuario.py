#este sera el modulo que vamos a exportar
def guardar():
    print("guardado")
    
def pagarImpuesto(user):
    print("pagando impuestos de: " + user.nombre)    