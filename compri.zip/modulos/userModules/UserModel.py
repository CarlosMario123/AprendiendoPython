class User():
    def __init__(self,nombre,correo,password):
        self.nombre = nombre
        self.correo = correo
        self.password = password
        