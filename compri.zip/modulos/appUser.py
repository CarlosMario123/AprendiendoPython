#para importar utilizamos from y nombre del archivo
#si importamos el asterico o todo 
#damos control espacio 
from usuario import guardar,pagarImpuesto

guardar()
pagarImpuesto()

