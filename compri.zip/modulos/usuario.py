#este sera el modulo que vamos a exportar
def guardar():
    print("guardado")
    
def pagarImpuesto():
    print("pagando impuestos ")    