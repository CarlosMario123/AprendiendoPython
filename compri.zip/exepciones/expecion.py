try:#intentamos capturar el error
    numero = int(input("ingrese un numero"))
except:
    #mensaje de la exepcion
    print("tan dificil era agregar un numero?")